var gamelist = {
	"wandbox": "https://wandbox.org",
	"jsitor": "https://jsitor.com",
	"sshwifty": "https://sshwifty-demo.nirui.org",
};

var gamenames = {
	"wandbox": "Wandbox",
	"jsitor": "JSitor",
	"sshwifty": "SSHwifty",
};
